$(document).ready(function() {

    $('.subscribe-email').removeAttr('placeholder');
    $('.subscribe-email').val('Entrez votre email...');

});